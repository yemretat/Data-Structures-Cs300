#include<iostream>
#include<string>
#include<fstream>
#include<vector>
#include<sstream>
#include<math.h>
#include"Header.h"
using namespace std;
int global=0;//when a rectangle insert as horizontal or vertically then global will be 1 and out of searchinloop.When searcing again point it will be 0 again
tree::tree()
{
	root=NULL;//root pointer firstly points the NULL
}
void tree:: insertingroot(Rectangle a)
{//it is for first node creating.Root is a private pointer and it shows the first node of the tree.
	node *p;
	if(root==NULL)
	{
		p=new node(a);
		root =p;
		return;
	}
}
void tree::searcher(node *t,vector<Rectangle>&x,Point p)//it is a searcher function when we search a point in the nodes which their extent cover our point
{//searcing function is that getting a node and search these nodes vectors for finding a point is in or out
	vector<Rectangle>k=t->returnerhorizontal();//taking horizontal vector of the node
	vector<Rectangle>y=t->returnervertical();//taking vertical nodes

	for(int i=0;i<k.size();i++)
	{
		if(findepoint(p,k[i]))//if it is finded push our vector which stores rectangles which cover points
		{
			x.push_back(k[i]);
		}
	}
	for(int i=0;i<y.size();i++)//if it is finded push our vector which stores rectangles which cover points
	{
		if(findepoint(p,y[i]))
		{
			x.push_back(y[i]);
		}
	}

}
int tree::findingarea(Point p,node *t)//giving a point and then finding the right direction (topleft,topright,bottomleft,bottomright) for its coordinates
{//finding area is searcing a point in the rectangles and it returns a number as its direction.0 is topleft,1 is topright,2 is bottomleft,3 is bottomright
	int kk=0;
	Rectangle s=t->returnrectangle();
	int top=s.gettingtop(),bottom=s.gettingbot(),left=s.gettingleft(),right=s.gettingright();

	if(p.x <= (right+left)/2 && p.y<=(bottom+top)/2)
	{
		return kk;//0 means topleft
	}
	else if( p.x>(right+left)/2 && p.y<=(bottom+top)/2)
	{
		kk=1;
		return kk;//1 means topright
	}
	else if(p.x<=(right+left)/2 && p.y>(bottom+top)/2)
	{
		kk=2;
		return kk; //2 means bottomleft
	}
	else if(p.x>(right+left)/2 && p.y>(bottom+top)/2)
	{
		kk=3;
		return kk;//3 means bottomright
	}
	
}
int tree::finded(node *t,Rectangle s)
{//finded is a function that a finding a rectangle is in horizontal or vertical or neither of them.1 returns vertical.2 returns horizontal 0 means it is not in
	int f=0;
	Rectangle a=t->returnrectangle();
	int x=(a.gettingleft()+a.gettingright())/2;//to find the center node's rectangle 
	int y=(a.gettingtop() + a.gettingbot())/2;//
	if(s.gettingleft()<=x &&x<s.gettingright())
	{
		f=2;// means it is in the vertical part
		return f;
	}
	else if(y>=s.gettingtop() && y<s.gettingbot())
	{
		f=1;// mens it is in the horizontal part
		return f;
	}
	else
	{
		return f;
	}

}

void tree::insert(Rectangle a)
{//inserting function is that firstly in insertingroot function we created root for first node and as the coordinates I create the rectangles for tree to find 
	//true place by input rectangles
	while(global==0){
	node *t=root;
	node *r=NULL;
	node *p;
	int decisionmaker =0;//decision maker means you did not get the rectangle line you have to try again until it is 1
	int tamtakim=0;//it is integer to assign as its coordinates if a point in rectangle's topleft then it is 0,topright 1,bottomleft 2,bottomright 3
	Rectangle b;
	while(t!=NULL)
	{
		r=t;
		b.settingbot(t->returnrectangle().gettingbot()),b.settingleft(t->returnrectangle().gettingleft());b.settingright(t->returnrectangle().gettingright()),b.settingtop(t->returnrectangle().gettingtop());
		int findednum=finded(t,a);//it returns 0 iff I did not find in horizontally or vertically.
		if(findednum==0)//case of vertical pr horizontala not taking 
		{
			int pp=findingtrueplace(t,a);
			if(pp==0)//go to the top left
			{
				tamtakim=0;
				t=t->returnertl();
			}
			else if(pp==1)//go to the top right
			{
				tamtakim=1;
				t=t->returnertr();
			}
			else if(pp==2)//go to the bottom left
			{
				tamtakim=2;
				t=t->returnerbl();
			}
			else if(pp=3)//go to the bottom right
			{
				tamtakim=3;
				t=t->returnerbr();
			}

		}//global 1 means it is pushed you can get the new line;
		else if(findednum==1)//if it is one then that means � find in horizontal point
		{
			t->returnerhorizontal().push_back(a);
			decisionmaker=1;
			global=1;
			t=NULL;

		}
		else if(findednum==2)//means � found in vertical part to � pushed
		{
			t->returnervertical().push_back(a);
			decisionmaker =1;
			global=1;
			t=NULL;

		}
	}
	
	if(decisionmaker ==0)//when � did not push any where it means � have to extent my tree to find true place my inputs
	{
		global=0;//bir node insertledik art�k looptan ��k demek 
		Rectangle a2;
		if(tamtakim==0)//extenting topleft
		{
			a2.settingbot(floor((b.gettingbot()+b.gettingtop())/2));a2.settingtop(b.gettingtop());
			a2.settingright(floor((b.gettingright()+b.gettingleft())/2));a2.settingleft(b.gettingleft());
			p=new node (a2);
			r->returnertl()=p;}
		else if(tamtakim==1)//extenting topright
		{
			a2.settingbot(floor((b.gettingbot()+b.gettingtop())/2));a2.settingtop(b.gettingtop());
			a2.settingright(b.gettingright());
			a2.settingleft(floor((b.gettingright()+b.gettingleft())/2)+1);
			p=new node (a2);
			r->returnertr()=p;
		}
		else if(tamtakim==2)//extenting bottomleft
		{	a2.settingtop(floor((b.gettingbot()+b.gettingtop())/2)+1);
		a2.settingright(floor((b.gettingright()+b.gettingleft())/2));
		a2.settingleft(b.gettingleft());a2.settingbot(b.gettingbot());
		p=new node (a2);
		r->returnerbl()=p;         }
		else //extenting bottomright
		{
			a2.settingbot(b.gettingbot());
			a2.settingtop(floor((b.gettingbot()+b.gettingtop())/2)+1);
			a2.settingleft(floor((b.gettingright()+b.gettingleft())/2)+1),a2.settingright(b.gettingright());
			p=new node (a2);
			r->returnerbr()=p;   }
	}

	}
	global=0;
}
bool tree::findepoint(Point p,Rectangle a)
{
	if(p.x<a.gettingright() && a.gettingleft()<=p.x && a.gettingbot()>p.y && a.gettingtop()<=p.y)
	{//if a point locaed in the rectangle then it returns the true if not return false
		return true;		
	}
	else
	{
		return false;
	}
}
int tree::findingtrueplace(node *t,Rectangle k)
{//getting a node's rectangle and a input rectangle and determining if this rectangle located in node's extent
	int kk=0;
	Rectangle s=t->returnrectangle();
	int top=s.gettingtop(),bottom=s.gettingbot(),left=s.gettingleft(),right=s.gettingright();
	if(k.gettingright() <= (right+left)/2 && k.gettingbot()<=(bottom+top)/2)//means it is located in the top left of the extenxt
	{
		return kk;
	}
	else if( k.gettingright()>(right+left)/2 && k.gettingbot()<=(bottom+top)/2)//means it is located in the top right of the extent
	{
		kk=1;
		return kk;
	}
	else if(k.gettingright()<=(right+left)/2 && k.gettingbot()>(bottom+top)/2)//means it is located in the bottom left of the extent
	{
		kk=2;
		return kk;
	}
	else if(k.gettingright()>(right+left)/2 && k.gettingbot()>(bottom+top)/2)//means it is located in the bottom rigth of the extent
	{
		kk=3;
		return kk;
	}
}
vector<Rectangle> tree::binarysearchtree(Point p)
{//searcing algorithm for the given point coordinates
	vector<Rectangle>storage;
	int k=0;
	node *t=root;
	while(t!=NULL)//visiting the available nodes for the searching we have a point and start from the root to the deep of the tree 
	{
		searcher(t,storage,p);
		k=findingarea(p,t);//it finds that where should we visit topleft,topright,bottomleft,bottomright in order
		if(k==0)
		{t=t->returnertl();}
		if(k==1)
		{t=t->returnertr();}
		if(k==2)
		{t=t->returnerbl();}
		if(k==3)
		{t=t->returnerbr();}
	

	}
	return storage;
}
void Rectangle::creatingrec(vector<int>x)
{
top=x[0],left=x[1],bottom=x[2],right=x[3];//it is the function that takes the vector 4 size and assign the private members
}
void tree::searhingprocessor(int x,int y,vector<vector<Rectangle>>&a,vector<Point>&t,vector<int>&intvec)
{//it stores the coordinates of the given point,and matrix for the storing the points rectangles in order,intvec is for storing how many rectangles are cover point
	Point p;p.x=x;p.y=y;
	vector<Rectangle>tt=binarysearchtree(p);
	intvec.push_back(tt.size());
	a.push_back(tt);
	t.push_back(p);
}
void tree::printingthealgorithm(vector<vector<Rectangle>>matrix,vector<Point>t,vector<int>integers)
{//printing function in order point,number of rectangles,rectangles coordinates
	for(int i=0;i<t.size();i++)
	{
		cout<<t[i].x<<" "<<t[i].y<<endl;
		cout<<integers[i]<<endl;
		for(int k=0;k<matrix[i].size();k++)//is a loop for printing the matrix who have all the rectangles which is the point covered
		{
			cout<<matrix[i][k].gettingtop()<<" "<<matrix[i][k].gettingleft()<<" "<<matrix[i][k].gettingbot()<<" "<<matrix[i][k].gettingright()<<endl;
		}

	}

}








