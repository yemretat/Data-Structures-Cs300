#include"Header.h"
#include<fstream>
#include<iostream>
#include<string>
#include<fstream>
#include<vector>
#include<sstream>
#include<math.h>
using namespace std;
int main()
{
	ifstream f;
	f.open("rectdb.txt");
	string line;
	int num;
	Rectangle k;
	tree t;
	getline(f,line);
	stringstream ss(line);
	vector<int> x;
	while(ss>>num)
	{
		x.push_back(num);//x is a vector to store rect. coordinates
	}
	k.creatingrec(x);
	t.insertingroot(k);//first node will be created
	string line1;
	while(getline(f,line1))
	{
		stringstream aa(line1);
		x.clear();
		while(aa>>num)
		{
			x.push_back(num);
		}
		if(x[0]!=-1){//if(line1!="-1")// if the last line is -1 it means it is the end of the input
		k.creatingrec(x);
		t.insert(k);}
		
		
	}
	vector<vector<Rectangle>> matrix;//matrix will store the all input points rectangles which cover the point
	vector<Point> pointvec;//storing the points which are input
	vector<int> intvec;//storing number of the rectangles which input point located
	int p1,p2;
	while(cin>>p1>>p2)
	{
		if(p1!=-1)
		{t.searhingprocessor(p1,p2,matrix,pointvec,intvec);//searcing a a point 
		}
		else{break;}
	}
	t.printingthealgorithm(matrix,pointvec,intvec);//printing the point,number of rect,rectangles coordinates
	
	
	
	
	

	




}
