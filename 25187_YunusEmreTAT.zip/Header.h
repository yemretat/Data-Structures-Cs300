#include<vector>
#ifndef  _HEADER_H
#define _HEADER_H
using namespace std;
struct Point{// point can store two dim 
	int x;
	int y;
};
class Rectangle
{
private:
	int top;int bottom;int left;int right;//rectangle extents
public:
	Rectangle()
		:top(0),bottom(0),left(0),right(0)//constructor for rectangle firstly all of them is zero
	{}
	void creatingrec(vector<int>x);
	void settingtop(int topi){top=topi;};//setting functions is for accesing and regulating the private members
	void settingleft(int lefti){left=lefti;};
	void settingright(int righti){right=righti;};
	void settingbot(int boti){bottom=boti;};
	int gettingtop(){return top;};//getting function to get the private numbers
	int gettingbot(){return bottom;};
	int gettingright(){return right;};
	int gettingleft(){return left;};
};
class node
{//a node have extent of its rectangle and 2 vectors to store the intersected rectangles horizontally or vertically and have 4 pointers to creating the tree
private:
	Rectangle extent;
	vector<Rectangle> vertical,horizontal;
	node *topleft,*topright,*bottomleft,*bottomright;
public:
	node(Rectangle a)
		:topleft(NULL),topright(NULL),bottomleft(NULL),bottomright(NULL),extent(a)
	{}
	node *&returnertl(){return topleft;};//these function to creating the tree we need change a node's pointers with these functions 
	node *&returnertr(){return topright;};
	node *&returnerbl(){return bottomleft;};
	node *&returnerbr(){return bottomright;};
	vector<Rectangle>&returnervertical(){return vertical;};//takings its vectors and pushing some elements
	vector<Rectangle>&returnerhorizontal(){return horizontal;};
	Rectangle& returnrectangle(){return extent;};
};
class tree
{// all of the functions are explained in the source part
private:
	node *root;
	int findingarea(Point p,node *t);
	void  searcher(node *t,vector<Rectangle>&x,Point p);
	bool findepoint(Point p,Rectangle a);
	int findingtrueplace(node *t,Rectangle k);
	int finded(node *t,Rectangle s);
public:
	tree();
	void insertingroot(Rectangle a);
	void insert(Rectangle a);
	vector<Rectangle> binarysearchtree(Point p);
	void searhingprocessor(int x,int y,vector<vector<Rectangle>>&a,vector<Point>&t,vector<int>&intvec);
	void printingthealgorithm(vector<vector<Rectangle>>a,vector<Point>t,vector<int>integers);

};

















#endif
